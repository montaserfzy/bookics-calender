DayPilot Pro for JavaScript (Vue.js)
===================================

Product information
-------------------
https://javascript.daypilot.org/

NPM package
-----------
https://npm.daypilot.org/